(() => {
  const socket = io();
})();
